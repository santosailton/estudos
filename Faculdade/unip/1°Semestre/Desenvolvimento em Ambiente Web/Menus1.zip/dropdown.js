// C�digo publicado por Nick Rigby baseado no original de Patrick Griffiths
function IEHoverPseudo() {
	var navItems = document.getElementById("nav").getElementsByTagName("li");
		for (var i=0; i<navItems.length; i++) {
		if(navItems[i].className == "submenu") {
			navItems[i].onmouseover=function() { this.className += " over"; }
			navItems[i].onmouseout=function() { this.className = "submenu"; }
		}
	}
}
window.onload = IEHoverPseudo;

