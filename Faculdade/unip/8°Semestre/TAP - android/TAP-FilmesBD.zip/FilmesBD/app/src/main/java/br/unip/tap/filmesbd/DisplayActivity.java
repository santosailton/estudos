package br.unip.tap.filmesbd;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

/**
 * Classe para exibição dos dados relativos a um filme,
 * permitindo através do seu menu de opções que as informações
 * sejam alteradas ou mesmo o registro seja apagado.
 */
public class DisplayActivity extends AppCompatActivity {

    private FilmesBDHelper mBD;

    private Filme filme;
    private EditText titulo;
    private EditText subtitulo;
    private EditText genero;
    private RatingBar avaliacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        Toolbar mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);

        mBD = new FilmesBDHelper(this);

        // Recuperando a instância de filme passado
        // através do Intent
        Bundle extra = getIntent().getExtras();
        filme = (Filme) extra.get("filme");

        // Populando os campos dos componentes com o
        // conteúdo do filme (informações do objeto)
        titulo = (EditText) findViewById(R.id.etTitulo);
        titulo.setText(filme.getTitulo());
        subtitulo = (EditText) findViewById(R.id.etSubtitulo);
        subtitulo.setText(filme.getSubtitulo());
        genero = (EditText) findViewById(R.id.etGenero);
        genero.setText(filme.getGenero());
        avaliacao = (RatingBar) findViewById(R.id.rbAvaliacao);
        avaliacao.setRating(filme.getAvaliacao());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_display, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.mAtualizar:
                // atualiza as informações do objeto filme, e ...
                filme.setTitulo(titulo.getText().toString());
                filme.setSubtitulo(subtitulo.getText().toString());
                filme.setGenero(genero.getText().toString());
                filme.setAvaliacao(avaliacao.getRating());
                // passa-o como parametro para o método criado
                // na nossa implementação do SQLiteOpenHelper.
                mBD.atualizar(filme);
                return true;
            case R.id.mRemover:

                // Confirmando a operação com uma janela de diálogo
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage(R.string.dlg_apagar)
                        .setPositiveButton(R.string.sim,
                                // ... se a clicar no botão "Sim"
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        // usando o ID existente do objeto, invocamos a remoção
                                        mBD.remover(filme.getId());
                                        // uma msg rápida confirmando o sucesso da execução
                                        Toast.makeText(getApplicationContext(),"Filme apagado com sucesso!", Toast.LENGTH_SHORT).show();
                                        // e retorna para a tela principal (Feed de Filmes)
                                        Intent intent = new Intent(getApplicationContext(), FeedFilmesActivity.class);
                                        startActivity(intent);
                                    }
                                }
                        )
                        .setNegativeButton(R.string.nao,
                                // ... se a clicar no botão "Não"
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        // nada a ser feito :)
                                    }
                                }
                        );
                AlertDialog dlg = builder.create();
                dlg.setTitle("Confirme:");
                dlg.show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
