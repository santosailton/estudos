package br.unip.tap.filmesbd;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Activity que exibe uma lista com todos os filmes armazenados
 * no banco de dados.
 */
public class FeedFilmesActivity extends AppCompatActivity implements ListView.OnItemSelectedListener {

    private FilmesBDHelper mBD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feed_filmes);
        Toolbar mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);

        mBD = new FilmesBDHelper(this);

        Cursor cursor = mBD.getCursorFilmes();

        ListAdapter adapter = new SimpleCursorAdapter(this,
                android.R.layout.simple_list_item_2,
                cursor,
                new String[] {FilmesBDHelper.FilmesDesc.COL_TITULO, FilmesBDHelper.FilmesDesc.COL_SUBTITULO},
                new int[] {android.R.id.text1, android.R.id.text2}
        );
        startManagingCursor(cursor);

        ListView feed = (ListView) findViewById(R.id.lFeedFilmes);
        feed.setAdapter(adapter);
        feed.setOnItemSelectedListener(this);
    }

    // callback para a criação do menu de opções, presente
    // na barra superior do app (Toolbar) no lado direto.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_feed, menu);
        return true;
    }

    // callback para tratamento dos eventos de clique (seleção)
    // de algum dos itens presentes no menu
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.mAdicionar:
                Intent intent = new Intent(getApplicationContext(),CadastrarActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    // Tratando eventos de seleção dos itens da lista de filmes
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        String item = adapterView.getItemAtPosition(i).toString();
        Toast.makeText(adapterView.getContext(), "Selecionado: " + item, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) { }

}
