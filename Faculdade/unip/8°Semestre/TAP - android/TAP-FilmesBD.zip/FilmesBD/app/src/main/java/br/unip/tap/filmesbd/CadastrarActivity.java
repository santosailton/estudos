package br.unip.tap.filmesbd;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.NotificationCompat;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;

/**
 * Activity responsável pelo cadastro de novos filmes
 */
public class CadastrarActivity extends AppCompatActivity {

    protected FilmesBDHelper mBD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar);
        Toolbar mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);

        // A interface Adapter é responsável por realizar o carregamento
        // de conteúdos sob demanda. Assim, como desejamos popular o
        // componente de seleção com os diferentes gêneros definidos
        // num dos arquivos de recurso, é necessário criar um ArrayAdapter
        // realizar o controle do componente.
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.generos, R.layout.support_simple_spinner_dropdown_item);
        adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);

        // Após recuperar a referencia ao objeto gráfico da tela, definimos
        // o Adapter que irá controlá-lo (carregamento do conteúdo, a expansão
        // dropdown e o item a ser apresentado).
        Spinner generos = (Spinner) findViewById(R.id.spGeneros);
        generos.setAdapter(adapter);

        mBD = new FilmesBDHelper(this);
    }

    /**
     * Callback que trata os eventos de click do botão Adicionar
     * (vide: layout/activity_cadastrar.xml)
     * @param view referência ao componente gráfico gerador do evento
     */
    public void Adicionar(View view) {

        String titulo    = ((EditText) findViewById(R.id.etTitulo)).getText().toString();
        String subtitulo = ((EditText) findViewById(R.id.etSubtitulo)).getText().toString();
        String genero    = ( (Spinner) findViewById(R.id.spGeneros)).getSelectedItem().toString();
        float avaliacao  = ((RatingBar) findViewById(R.id.rbAvaliacao)).getRating();

        Filme filme = new Filme();
        filme.setId( mBD.getNextID() );
        filme.setTitulo(titulo);
        filme.setSubtitulo(subtitulo);
        filme.setGenero(genero);
        filme.setAvaliacao(avaliacao);

        mBD.inserir(filme);

        /* Notificações:
         * É possível gerar notificações que fiquem na bandeja do sistema,
         * não apenas indicando informações mas também servindo de gatilho
         * para disparar uma ação (Intent)
         */
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
        builder.setSmallIcon(R.drawable.ic_stat_book);              // ícone
        builder.setContentTitle("Um novo filme foi adicionado!");   // título
        builder.setContentText(titulo + " - " + subtitulo +         // texto da msg
                " (" + genero + "): " + avaliacao);

        // Se for uma notificação clicável, devemos criar um Intent para
        // definir a ação que será realizada e os dados que serão passados
        Intent notificationIntent = new Intent(getApplicationContext(), DisplayActivity.class);
        notificationIntent.putExtra("filme", filme);

        PendingIntent contentIntent = PendingIntent.getActivity(
                getApplicationContext(), 0,
                notificationIntent, PendingIntent.FLAG_ONE_SHOT);

        // para desativar a notificação após o clique
        builder.setAutoCancel(true);

        // montando a notificação com: informações + intent (pendente) + dados,
        // e demais características que tenham sido definidas.
        builder.setContentIntent(contentIntent);


        // Recuperando a referencia do gerenciador de notificações para
        // então dispará-la com o método notify
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(0, builder.build());

        // ... e retornamos para a tela principal do app (Feed de Filmes)
        Intent intent = new Intent(getApplicationContext(), FeedFilmesActivity.class);
        startActivity(intent);
    }

}