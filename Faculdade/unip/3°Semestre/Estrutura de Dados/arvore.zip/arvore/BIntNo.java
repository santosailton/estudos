
class BIntNo{
   int valor;
   BIntNo esq, dir;

   BIntNo (int novoValor){
	  valor = novoValor;
   }
}
