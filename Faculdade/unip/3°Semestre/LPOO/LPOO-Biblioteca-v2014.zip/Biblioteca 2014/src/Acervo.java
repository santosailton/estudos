
public abstract class Acervo {

	private int codigo;
	private String titulo;
	private String editora;
	
	public Acervo() {
		this.codigo = 0;
		this.titulo = "<valor n�o informado>";
		this.editora = "<valor n�o informado>";
	}
	
	public Acervo(int codigo, String titulo, String editora) {
		this.codigo = codigo;
		this.titulo = titulo;
		this.editora = editora;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getEditora() {
		return editora;
	}

	public void setEditora(String editora) {
		this.editora = editora;
	}
	
	public abstract String fichaCatalografica();

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Acervo other = (Acervo) obj;
		if (codigo != other.codigo)
			return false;
		if (editora == null) {
			if (other.editora != null)
				return false;
		} else if (!editora.equals(other.editora))
			return false;
		if (titulo == null) {
			if (other.titulo != null)
				return false;
		} else if (!titulo.equals(other.titulo))
			return false;
		return true;
	}
	
	protected abstract Acervo clone();
	
}
