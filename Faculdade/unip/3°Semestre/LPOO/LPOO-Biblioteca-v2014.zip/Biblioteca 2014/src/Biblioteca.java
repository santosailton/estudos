import java.util.Vector;


public class Biblioteca {
	
	private Vector<Acervo> colecao;
	
	public Biblioteca() {
		colecao = new Vector<Acervo>(); 
	}

	public void adicionar(Acervo item) {
		colecao.add( item.clone() );
	}
	
	public void remover(Acervo item) {
		colecao.remove(item);
	}

	public Acervo consultar(int codigo) {
		Acervo temp = null;
		for (int i = 0; i < colecao.size(); i++) {
			if (colecao.elementAt(i).getCodigo() == codigo) {
				temp = colecao.elementAt(i).clone();
				break;
			}
		}
		return temp;
	}
	
	public Acervo consultar(String titulo) {
		Acervo temp = null;
		for (int i = 0; i < colecao.size(); i++) {
			if ( colecao.elementAt(i).getTitulo().equalsIgnoreCase(titulo) ) {
				temp = colecao.elementAt(i).clone();
				break;
			}
		}
		return temp;
	}
	
}
