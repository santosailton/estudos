import javax.swing.JOptionPane;


public class AppSistemaDeGerenciamentoBibliotecario {

	public static void main(String[] args) {
		
		JOptionPane.showMessageDialog(null,
				"Caro aluno,\n\n"
				+ "Bem vindo ao Sistema de Gerenciamento de uma Biblioteca\n"
				+ "constru�do durante as aulas da disciplina de LPOO. Este\n"
				+ "� um programa exemplo e utiliza os recursos das classes\n"
				+ "implementadas nas pr�ticas da disciplina.\n"
				+ "Durante o desenvolvimento empregamos v�rios fundamentos\n"
				+ "de Programa��o Orientada � Objetos, assim como recursos\n"
				+ "oferecidos pela linguagem Java.\n\n"
				+ "Bons estudos!",
				"Sistema de Gerenciamento Bibliotec�rio",
				JOptionPane.INFORMATION_MESSAGE);
		
		
		Livro livro;
		Periodico periodico;
		Acervo itemDoAcervo;
		Biblioteca biblioteca = new Biblioteca();
		
		String entrada;
		int confirmaEncerrar = -1;
		int opcaoDoMenu = -1;
		
		do {
			entrada = JOptionPane.showInputDialog(null,
					"Menu principal:\n\n"
					+ "1. Adicionar um novo Livro ao acervo\n"
					+ "2. Adicionar um novo Peri�dico ao acervo\n"
					+ "3. Consultar um �tem do acervo (por c�digo)\n"
					+ "4. Consultar um �tem do acervo (pelo t�tulo)\n"
					+ "5. Remover um �tem do acervo\n"
					+ "6. Listar a cole��o completa\n"
					+ "7. Encerrar o programa\n\n"
					+ "Qual op��o deseja?",
					"Sistema de Gerenciamento Bibliotec�rio", JOptionPane.PLAIN_MESSAGE);
			opcaoDoMenu = Integer.parseInt(entrada);
			
			switch (opcaoDoMenu) {
			case 1:
				//TODO: Coletar as informa��es do usu�rio e popular os campos do objeto
				livro = new Livro();
				biblioteca.adicionar(livro);
				break;
			case 2:
				//TODO: Coletar as informa��es do usu�rio e popular os campos do objeto
				periodico = new Periodico();
				biblioteca.adicionar(periodico);
				break;
			case 3:
				entrada = JOptionPane.showInputDialog(null,
						"Qual � o c�digo do item que deseja consultar?",
						"Consultar �tem do acervo", JOptionPane.PLAIN_MESSAGE);
				int codigo = Integer.parseInt(entrada);
				itemDoAcervo = biblioteca.consultar(codigo);
				if (itemDoAcervo == null)
					JOptionPane.showMessageDialog(null,
							"N�o foram encontrados livros ou peri�dicos com este c�digo.",
							"Consultar �tem do acervo", JOptionPane.WARNING_MESSAGE);
				else
					JOptionPane.showMessageDialog(null,
							itemDoAcervo.fichaCatalografica(),
							"Consultar �tem do acervo", JOptionPane.INFORMATION_MESSAGE);
				break;
			case 4:
				entrada = JOptionPane.showInputDialog(null,
						"Qual � o c�digo do item que deseja consultar?",
						"Consultar �tem do acervo", JOptionPane.PLAIN_MESSAGE);
				itemDoAcervo = biblioteca.consultar(entrada);
				if (itemDoAcervo == null)
					JOptionPane.showMessageDialog(null,
							"N�o foram encontrados livros ou peri�dicos com este t�tulo.",
							"Consultar �tem do acervo", JOptionPane.WARNING_MESSAGE);
				else
					JOptionPane.showMessageDialog(null,
							itemDoAcervo.fichaCatalografica(),
							"Consultar �tem do acervo", JOptionPane.INFORMATION_MESSAGE);
				break;
			case 5:
				entrada = JOptionPane.showInputDialog(null,
						"Qual � o c�digo do item que deseja remover?",
						"Excluir �tem do acervo", JOptionPane.PLAIN_MESSAGE);
				codigo = Integer.parseInt(entrada);
				itemDoAcervo = biblioteca.consultar(codigo);
				if (itemDoAcervo == null)
					JOptionPane.showMessageDialog(null,
							"Imposs�vel excluir o item, pois n�o foram encontrados livros ou peri�dicos com este c�digo.",
							"Excluir �tem do acervo", JOptionPane.WARNING_MESSAGE);
				else {
					biblioteca.remover(itemDoAcervo);
					JOptionPane.showMessageDialog(null,
							"O item:\n"
							+ itemDoAcervo.fichaCatalografica() + "\n"
							+ "foi removido do acervo da biblioteca.",
							"Excluir �tem do acervo", JOptionPane.INFORMATION_MESSAGE);
				}
				break;
			case 6:
				//TODO: Implementar a chamada ao m�todo ...
				break;
			case 7: // Encerrar o programa
				confirmaEncerrar = JOptionPane.showConfirmDialog(null,
						"Voc� deseja mesmo encerrar o programa?",
						"Encerrar", JOptionPane.OK_CANCEL_OPTION);
				break;
			default:
				JOptionPane.showMessageDialog(null,
						"Op��o inv�lida, voc� ter� que inform�-la novamente.",
						"Ops ...", JOptionPane.WARNING_MESSAGE);
			}
			
		} while (confirmaEncerrar != JOptionPane.OK_OPTION);
		
		System.exit(0);
		
	}

}
