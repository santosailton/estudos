
public class Livro extends Acervo {
	
	private String autorPrincipal;
	private int anoPublicacao;
	private int edicao;

	public Livro() {
		super();
		this.autorPrincipal = "<valor n�o informado>";
		this.anoPublicacao = 1900;
		this.edicao = 1;
	}

	public Livro(int codigo, String titulo, String editora,
			String autorPrincipal, int anoPublicacao, int edicao) {
		super(codigo, titulo, editora);
		this.autorPrincipal = autorPrincipal;
		this.anoPublicacao = anoPublicacao;
		this.edicao = edicao;
	}
	
	public String getAutorPrincipal() {
		return autorPrincipal;
	}

	public void setAutorPrincipal(String autorPrincipal) {
		this.autorPrincipal = autorPrincipal;
	}

	public int getAnoPublicacao() {
		return anoPublicacao;
	}

	public void setAnoPublicacao(int anoPublicacao) {
		this.anoPublicacao = anoPublicacao;
	}

	public int getEdicao() {
		return edicao;
	}

	public void setEdicao(int edicao) {
		this.edicao = edicao;
	}

	@Override
	public String fichaCatalografica() {
		String msg = "------- Ficha Catalogr�fica -------\n"
				   + "T�tulo: " + getTitulo() + "\n"
				   + "Autor principal: " + getAutorPrincipal() + "\n"
				   + "Editora: " + getEditora() + "\n"
				   + "Edi��o: " + getEdicao()
				   + "\tAno de publica��o: " + getAnoPublicacao() + "\n"
				   + "-------------------------------------------------";
		return msg;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Livro other = (Livro) obj;
		if (anoPublicacao != other.anoPublicacao)
			return false;
		if (autorPrincipal == null) {
			if (other.autorPrincipal != null)
				return false;
		} else if (!autorPrincipal.equals(other.autorPrincipal))
			return false;
		if (edicao != other.edicao)
			return false;
		return true;
	}
	
	@Override
	protected Acervo clone() {
		Livro temp = new Livro();
		
		temp.setCodigo( this.getCodigo() );
		temp.setTitulo( this.getTitulo() );
		temp.setEditora( this.getEditora() );
		temp.setAutorPrincipal( this.autorPrincipal );
		temp.setAnoPublicacao( this.anoPublicacao );
		temp.setEdicao( this.edicao );
		
		return temp;
	}

}