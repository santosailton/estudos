
public class Periodico extends Acervo {
	
	public static final int SEMANAL  = 0;
	public static final int MENSAL   = 1;
	public static final int ANUAL    = 2;
	public static final int ESPECIAL = 3;
	
	private int ano;
	private int fasciulo;
	private int frequencia;
	
	public Periodico() {
		super();
		this.ano = 1;
		this.fasciulo = 1;
		this.frequencia = SEMANAL;
	}

	public Periodico(int codigo, String titulo, String editora,
			int ano, int fasciulo, int frequencia) {
		super(codigo, titulo, editora);
		this.ano = ano;
		this.fasciulo = fasciulo;
		this.frequencia = frequencia;
	}
	
	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	public int getFasciulo() {
		return fasciulo;
	}

	public void setFasciulo(int fasciulo) {
		this.fasciulo = fasciulo;
	}

	public String getFrequencia() {
		String freq = "<n�o definida>";
		switch (frequencia) {
		case SEMANAL:
			freq = "Semanal";
			break;
		case MENSAL:
			freq = "Mensal";
			break;
		case ANUAL:
			freq = "Anual";
			break;
		case ESPECIAL:
			freq = "Edi��o especial";
			break;
		}
		return freq;
	}

	public void setFrequencia(int frequencia) {
		this.frequencia = frequencia;
	}

	@Override
	public String fichaCatalografica() {
		String msg = "------- Ficha Catalogr�fica -------\n"
				   + "T�tulo: " + getTitulo() + "\n"
				   + "Editora: " + getEditora() + "\n"
				   + "Ano: " + getAno() + "\tFasc�culo: " + getFasciulo() + "\n"
				   + "Tiragem (freq.): " + getFrequencia() + "\n"
				   + "-------------------------------------------------";
		return msg;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Periodico other = (Periodico) obj;
		if (ano != other.ano)
			return false;
		if (fasciulo != other.fasciulo)
			return false;
		if (frequencia != other.frequencia)
			return false;
		return true;
	}

	@Override
	protected Acervo clone() {
		Periodico temp = new Periodico();
		
		temp.setCodigo( this.getCodigo() );
		temp.setTitulo( this.getTitulo() );
		temp.setEditora( this.getEditora() );
		temp.setAno( this.ano );
		temp.setFasciulo( this.fasciulo );
		temp.setFrequencia( this.frequencia );
		
		return temp;
	}
}
