/**
 * @author leandro
 * @since 04/ABR/2008
 *
 */

import javax.swing.*; 

public final class Principal
{
	/*
	 * Esse m�todo recebe como par�metro um objeto que seja um descendente da 
	 * classe Conta, haja vista que por ser uma classe abstrata n�o pode ser
	 * instanciada. Assim, independentemente de qual seja a classe derivada
	 * sempre haver� um m�todo extrato a ser invocado, ocorrendo desta forma,
	 * a chamada ao m�todo adequado (alguma reescrita do original).
	 */
	public static void mostraExtrato(Conta c){
		JOptionPane.showMessageDialog(null,
				c.extrato(),
				"Extrato (Gen�rico)",JOptionPane.PLAIN_MESSAGE);	
	}
	
	public static void main(String[] args) {
		
		String nome, agencia, conta, deposito, saque, limite;
		
		ContaBasica cb = new ContaBasica();
		ContaEspecial ce = new ContaEspecial();
		
		JOptionPane.showMessageDialog(null,
				"Veja como funciona a conta comum.\n"+
				"Fa�a um teste digitando os valores solicitados e verifique as respostas (sa�das) na console");

		nome = JOptionPane.showInputDialog(null,"Entre com o nome do correntista:");
		agencia = JOptionPane.showInputDialog(null,"Entre com o numero da agencia:");
		conta = JOptionPane.showInputDialog(null,"Entre com o numero da conta:");
		
		cb.setDadosDaConta(
				Integer.parseInt(agencia),
				Integer.parseInt(conta),
				nome,
				0);
		
		Principal.mostraExtrato(cb);
		
		deposito = JOptionPane.showInputDialog(null, "Entre com o valor do dep�sito:");
		
		cb.deposito(Double.parseDouble(deposito));
		
		Principal.mostraExtrato(cb);
		
		saque = JOptionPane.showInputDialog(null,"Entre com o valor do saque:");
		
		if (! cb.saque(Double.parseDouble(saque)) )
			JOptionPane.showMessageDialog(null,
					"Saldo insuficiente para efetuar esse saque",
					"Saque n�o efetuado",0);
		else
			JOptionPane.showMessageDialog(null,
					"O saque foi efetuado com sucesso",
					"Saque efetuado",2);
		
		Principal.mostraExtrato(cb);

		/* Segundo exemplo */
		
		JOptionPane.showMessageDialog(null,
				"Agora vamos testas a conta especial.\n" +
				"Procederemos da mesma maneira, informe os dados e acompanhe as sa�das na console");
		
		nome = JOptionPane.showInputDialog(null,"Entre com o nome do correntista:");
		agencia = JOptionPane.showInputDialog(null,"Entre com o numero da agencia:");
		conta = JOptionPane.showInputDialog(null,"Entre com o numero da conta:");

		ce.setDadosDaConta(
				Integer.parseInt(agencia),
				Integer.parseInt(conta),
				nome,
				0);
		
		Principal.mostraExtrato(ce);
		
		limite = JOptionPane.showInputDialog(null,"Entre com o limite da conta:");
		
		ce.setLimite(Double.parseDouble(limite));
		
		deposito = JOptionPane.showInputDialog(null,"Entre com o valor do dep�sito:");
		
		ce.deposito(Double.parseDouble(deposito));
		
		Principal.mostraExtrato(ce);
		
		saque = JOptionPane.showInputDialog(null,"Entre com o valor do saque:");
		
		if (! ce.saque(Double.parseDouble(saque)) )
			JOptionPane.showMessageDialog(null,
					"Saldo insuficiente para efetuar esse saque",
					"Saque n�o efetuado",0);
		else
			JOptionPane.showMessageDialog(null,
					"O saque foi efetuado com sucesso",
					"Saque efetuado",2);
		
		Principal.mostraExtrato(ce);
		
		System.exit(0);
	}
}