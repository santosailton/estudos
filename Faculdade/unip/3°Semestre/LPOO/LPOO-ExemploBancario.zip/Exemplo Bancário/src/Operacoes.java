/**
 * @author leandro
 * @since 04/ABR/2008
 *
 */

public interface Operacoes
{
	public abstract void deposito(double valor);
	public abstract boolean saque(double valor);
}
