/**
 * @author leandro
 * @since 04/ABR/2008
 *
 * A classe ContaPoupan�a representa uma conta de poupan�a com 
 * data de anivers�rio e taxa de remunera��o do saldo. Esta classe 
 * utiliza a defini�ao b�sica de uma conta banc�ria atrav�s da 
 * heran�a da classe Conta.
 */

public class ContaPoupanca extends Conta 
{
	int data;
	double taxa;
	
	public ContaPoupanca(){
		this(0,0,"",0,1,0.08);
	}

	public ContaPoupanca(int agencia,int numeroDaConta,String titular,double saldo,int data,double taxa){
		super(agencia,numeroDaConta,titular,saldo);
		setData(data);
		setTaxa(taxa);
	}
	
	public void setData(int data){	this.data = data; }
	
	public void setTaxa(double taxa){ this.taxa = taxa;	}
	
	public int getData(){ return data; }
	
	public double getTaxa(){ return taxa; }
	
	public String extrato(){
		return "    -:: EXTRATO DE POUPANCA ::-    "+"\n"+
			   "==================================="+"\n"+
			   "Ag......: "+agencia+"\tN.Conta: "+numeroDaConta+"\n"+
			   "Titular.: "+titular+"\n"+
			   "==================================="+"\n"+
			   "Saldo.......: "+saldo+"\n"+
			   "Anivers�rio.: "+data+"\n"+
			   "Remunera��o.: "+(saldo*taxa)+"\n"+
			   "==================================="+"\n";
	}
	
	/* Implementa��o obrigat�ria do m�todo abstrato */
	public boolean saque(double valor){
		if (valor > saldo)
			return false;
		saldo -= valor;
		return true;	
	}
	
}