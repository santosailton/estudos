/**
 * @author leandro
 *
 * A classe ContaBasica representa a defini�ao b�sica de uma conta banc�ria
 */

public class ContaBasica extends Conta
{
	/* Implementa��o obrigat�ria do m�todo abstrato */
	public boolean saque(double valor){
		if (valor > saldo)
			return false;
		saldo -= valor;
		return true;		
	}
}