/**
 * @author Leandro Carlos Fernandes
 * @since 04/ABR/2008
 *
 * Essa classe implementa a solu��o do exerc�cio 6 da primeira lista
 * A classe Conta representa a defini�ao abstrata de uma conta banc�ria
 */

public abstract class Conta
{
	int agencia;
	int numeroDaConta;
	String titular;
	double saldo;
   
	public Conta(){
		this(0,0,"",0);
	}

	public Conta(int agencia, int numeroDaConta, String titular, double saldo){
		setDadosDaConta(agencia,numeroDaConta,titular,saldo);
	}
	
	public void setDadosDaConta(int agencia, int numeroDaConta, String titular, double saldo){
		this.agencia = agencia;
		this.numeroDaConta = numeroDaConta;
		this.titular = titular;
		this.saldo = saldo;
  	}
	
	public int getAgencia(){ return agencia; }
	
	public int getNumeroDaConta(){ return numeroDaConta; }
	
	public String getTitular(){	return titular;	}
	
	public double getSaldo(){ return saldo;	}
	
	public final void deposito(double valor){
		this.saldo += valor; 
	}
	
	public abstract boolean saque(double valor);
	
	public String extrato(){
		return " -:::::: EXTRATO DE CONTA :::::::- "+"\n"+
			   "==================================="+"\n"+
			   "Ag......: "+agencia+"	N.Conta: "+numeroDaConta+"\n"+
			   "Titular.: "+titular+"\n"+
			   "==================================="+"\n"+
			   "Saldo......: "+saldo+"\n"+
			   "==================================="+"\n";
	}
}