/**
 * @author leandro
 * @since 04/ABR/2008
 *
 * A classe ContaEspecial representa uma conta corrente com limite 
 * de saldo. Esta classe utiliza a defini�ao b�sica de uma conta 
 * banc�ria atrav�s da heran�a da classe Conta.
 */

public class ContaEspecial extends Conta
{
	double limite;

	public ContaEspecial(){
		this(0,0,"",0,0);
	}
	
	public ContaEspecial(int agencia, int numeroDaConta, String titular, double saldo, double limite){
		super(agencia,numeroDaConta,titular,saldo);
		setLimite(limite);
	}
	
	public void setLimite(double limite){
		this.limite = limite;
	}
	
	public double getLimite(){
		return limite;
	}
	
	public String extrato(){
		return super.extrato()+
			   "Limite.....: "+limite+"\n"+
			   "Saldo disp.: "+(saldo+limite)+"\n"+
		   	   "==================================="+"\n";
	}
	
	/* Implementa��o obrigat�ria do m�todo abstrato */
	public boolean saque(double valor){
		if (valor > (saldo+limite))
			return false;
		saldo -= valor;
		return true;		
	}
}