public class LancheVersao1
{
	private int tipoDeCarne;
	private boolean queijo, ovo, presunto, bacon, salsicha, 
					alface,tomate,catupiry;
	private double valor;
	private static int qtde;

	public void adicionaQueijo(){
		queijo = true;
		valor += 0.10;
	}
	public void adicionaOvo(){
		ovo = true;
		valor += 0.20;
	}
	public void adicionaPresunto(){
		presunto = true;
		valor += 0.15;
	}
	public void adicionaBacon(){
		queijo = true;
		valor += 0.40;
	}
	public void adicionaSalsicha(){
		salsicha = true;
		valor += 0.30;
	}
	public void adicionaAlface(){
		alface = true;
		valor += 0.10;
	}
	public void adicionaTomate(){
		tomate = true;
		valor += 0.10;
	}
	public void adicionaCatupiry(){
		catupiry = true;
		valor += 0.70;
	}
	public void setTipoDeCarne(int carne){
		tipoDeCarne = carne;
	}


	public boolean temQueijo(){
		return queijo;
	}
	public boolean temOvo(){
		return ovo;
	}
	public boolean temPresunto(){
		return presunto;
	}
	public boolean temBacon(){
		return bacon;
	}
	public boolean temSalsicha(){
		return salsicha;
	}
	public boolean temAlface(){
		return alface;
	}
	public boolean temTomate(){
		return tomate;
	}
	public boolean temCatupiry(){
		return catupiry;
	}
	public int getTipoDeCarne(){
		return tipoDeCarne;
	}
	public double getValor(){
		return valor;
	}
	public int getQtde(){
		return qtde;
	}

	public LancheVersao1(int carne){
		tipoDeCarne = carne;
		queijo = ovo = presunto = bacon = salsicha = alface = tomate = catupiry = false;
		switch(carne){
			case 1: valor = 2.00;
					break;
			case 2: valor = 2.10;
					break;
			case 3: valor = 2.50;
					break;
			case 4: valor = 2.70;
					break;
			default:valor = 2.00;
					tipoDeCarne=1;
		}
		qtde ++;
	}
	public LancheVersao1(){
		this(1);
		adicionaQueijo();
	}
}