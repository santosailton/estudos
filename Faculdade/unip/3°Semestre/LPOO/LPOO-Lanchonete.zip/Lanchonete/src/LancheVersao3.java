public class LancheVersao3
{
	//Constantes que representam o tipo de carne ...	
	public final int HAMBURGER = 1;
	public final int FRANGO = 2;
	public final int LOMBO = 3;
	public final int FILE = 4;
	//... e os itens adicionais do Lanche 
	public final int QUEIJO = 0;
	public final int OVO = 1;
	public final int PRESUNTO = 2;
	public final int BACON = 3;
	public final int SALSICHA = 4;
	public final int ALFACE = 5;
	public final int TOMATE = 6;
	public final int CATUPIRY = 7;
	
	//Atributos
	private int tipoDeCarne;
	private boolean[] adicionais;
	private double valor;
	private static int qtde;
	
	public LancheVersao3(int carne){
		tipoDeCarne = carne;
		adicionais = new boolean[8];
		
		for (int i=0; i < 8; i++)
			adicionais[i] = false;
		
		switch(carne){
			case HAMBURGER:
				valor = 2.00;
				break;
			case FRANGO:
				valor = 2.10;
				break;
			case LOMBO:
				valor = 2.50;
				break;
			case FILE:
				valor = 2.70;
				break;
			default:
				valor = 2.00;
				tipoDeCarne = HAMBURGER;
		}
		qtde++;
	}
	public LancheVersao3(){
		this(1);
		adicionaItem(QUEIJO);
	}	
	
	public void adicionaItem(int item){
		adicionais[item] = true;
		switch (item) {
			case QUEIJO:   valor += 0.10; break;
			case OVO:      valor += 0.20; break;
			case PRESUNTO: valor += 0.15; break;
			case BACON:    valor += 0.40; break;
			case SALSICHA: valor += 0.30; break;
			case ALFACE:   valor += 0.10; break;
			case TOMATE:   valor += 0.10; break;
			case CATUPIRY: valor += 0.70; break;
		}
		
	}
	public void setTipoDeCarne(int carne){
		tipoDeCarne = carne;
	}

	public boolean temItem(int item){
		return adicionais[item];
	}
	
	public int getTipoDeCarne(){
		return tipoDeCarne;
	}
	
	public double getValor(){
		return valor;
	}
	
	public int getQtde(){
		return qtde;
	}

}