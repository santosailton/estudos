public class LancheVersao2
{
	//Constantes que representam o tipo de carne ...	
	public final int HAMBURGER = 1;
	public final int FRANGO = 2;
	public final int LOMBO = 3;
	public final int FILE = 4;
	//... e os itens adicionais do Lanche 
	public final int QUEIJO = 0;
	public final int OVO = 1;
	public final int PRESUNTO = 2;
	public final int BACON = 3;
	public final int SALSICHA = 4;
	public final int ALFACE = 5;
	public final int TOMATE = 6;
	public final int CATUPIRY = 7;
	
	//Atributos
	private int tipoDeCarne;
	private boolean[] adicionais;
	private double valor;
	private static int qtde;
	
	public LancheVersao2(int carne){
		tipoDeCarne = carne;
		adicionais = new boolean[8];
		
		for (int i=0; i < 8; i++)
			adicionais[i] = false;
		
		switch(carne){
			case HAMBURGER:
				valor = 2.00;
				break;
			case FRANGO:
				valor = 2.10;
				break;
			case LOMBO:
				valor = 2.50;
				break;
			case FILE:
				valor = 2.70;
				break;
			default:
				valor = 2.00;
				tipoDeCarne = HAMBURGER;
		}
		qtde++;
	}
	public LancheVersao2(){
		this(1);
		adicionaQueijo();
	}	
	
	public void adicionaQueijo(){
		adicionais[QUEIJO] = true;
		valor += 0.10;
	}
	public void adicionaOvo(){
		adicionais[OVO] = true;
		valor += 0.20;
	}
	public void adicionaPresunto(){
		adicionais[PRESUNTO] = true;
		valor += 0.15;
	}
	public void adicionaBacon(){
		adicionais[BACON] = true;
		valor += 0.40;
	}
	public void adicionaSalsicha(){
		adicionais[SALSICHA] = true;
		valor += 0.30;
	}
	public void adicionaAlface(){
		adicionais[ALFACE] = true;
		valor += 0.10;
	}
	public void adicionaTomate(){
		adicionais[TOMATE] = true;
		valor += 0.10;
	}
	public void adicionaCatupiry(){
		adicionais[CATUPIRY] = true;
		valor += 0.70;
	}
	public void setTipoDeCarne(int carne){
		tipoDeCarne = carne;
	}

	public boolean temQueijo(){
		return adicionais[QUEIJO];
	}
	public boolean temOvo(){
		return adicionais[OVO];
	}
	public boolean temPresunto(){
		return adicionais[PRESUNTO];
	}
	public boolean temBacon(){
		return adicionais[BACON];
	}
	public boolean temSalsicha(){
		return adicionais[SALSICHA];
	}
	public boolean temAlface(){
		return adicionais[ALFACE];
	}
	public boolean temTomate(){
		return adicionais[TOMATE];
	}
	public boolean temCatupiry(){
		return adicionais[CATUPIRY];
	}
	public int getTipoDeCarne(){
		return tipoDeCarne;
	}
	public double getValor(){
		return valor;
	}
	public int getQtde(){
		return qtde;
	}

}