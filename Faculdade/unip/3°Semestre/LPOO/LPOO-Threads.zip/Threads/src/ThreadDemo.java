class MinhaThreadComHeranca extends Thread {

	private int count;

	public MinhaThreadComHeranca() { count = 0; }
	public int getCount() {	return count; }
	public void setCount(int count) { this.count = count;}

	public void run() {
		System.out.println("Iniciando MinhaThread.");
		try {
			do {
			    Thread.sleep(500);
			    System.out.println("Em MinhaThread, o valor de count � " + count);
			    count++;
			} while (count < 5);
		} catch (InterruptedException exc) {
			System.out.println("A thread MinhaThread foi interrompida.");
		}
		System.out.println("Terminando MinhaThread.");
	}
}

public class ThreadDemo {

	public static void main(String[] args) {
		System.out.println("Main thread starting.");
		MinhaThreadComHeranca mt = new MinhaThreadComHeranca();
		mt.start();
		do {
			System.out.println("In main thread.");
			try {
				Thread.sleep(250);
			} catch (InterruptedException exc) {
				System.out.println("Main thread interrupted.");
			}
		} while (mt.getCount() != 5);
		System.out.println("Main thread ending.");
	}

}










