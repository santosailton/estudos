class MinhaThreadComRunnable implements Runnable {

	private int count;

	public MinhaThreadComRunnable() { count = 0; }
	public int getCount() {	return count; }
	public void setCount(int count) { this.count = count;}

	public void run() {
		System.out.println("Iniciando MinhaThread.");
		try {
			do {
			    Thread.sleep(500);
			    System.out.println("Em MinhaThread, o valor de count � " + count);
			    count++;
			} while (count < 5);
		} catch (InterruptedException exc) {
			System.out.println("A thread MinhaThread foi interrompida.");
		}
		System.out.println("Terminando MinhaThread.");
	}
}

public class RunnableDemo {

	public static void main(String[] args) {

		System.out.println("Iniciando thread Main.");
		MinhaThreadComRunnable mt = new MinhaThreadComRunnable();
		Thread novaThread = new Thread(mt);
		novaThread.start();
		
		do {
			System.out.println("thread Main.");
			try {
				Thread.sleep(250);
			} catch (InterruptedException exc) {
				System.out.println("A thread Main foi interrompida.");
			}
	    } while (mt.getCount() != 5);

	    System.out.println("Terminando thread Main.");
	}

}





