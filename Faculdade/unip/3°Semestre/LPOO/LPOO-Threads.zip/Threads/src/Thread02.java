public class Thread02 {

	public static void main( String args[] )
   {
      System.out.println("Main: Inicio da Thread main()\n");

      ThreadBasica thread1, thread2, thread3, thread4;
      thread1 = new ThreadBasica( "thread1",1 );
      thread2 = new ThreadBasica( "thread2",2 );
      thread3 = new ThreadBasica( "thread3",3 );
      thread4 = new ThreadBasica( "thread4",4 );

      System.out.println( "\nMain: Disparando as threads" );
      thread1.start();
      thread2.start();
      thread3.start();
      thread4.start();

      System.out.println("Main: Fim da Thread main()\n");
   }
}

class ThreadBasica extends Thread {
   int tempo_de_sono;
   int numero_da_thread;

   public ThreadBasica(String nome, int numero) {
      super( nome );
      numero_da_thread = numero;
      tempo_de_sono = (int) ( Math.random() * 5000 ); 

      if(numero == 1) this.setPriority(1);
      if(numero == 2) this.setPriority(9);
      System.out.println("Nome: " + getName() + ";  tempo do sono: " + tempo_de_sono + ";  Prioridade:" +getPriority() );
   }

   public void run() {
      System.out.println("Comeco do metodo run() da thread " + this.getName());
      for(int i=0;i<100;i++)
    	  System.out.print(this.numero_da_thread);
      System.out.println();
      System.out.println( getName() + " vai acabar" );
   }
}









