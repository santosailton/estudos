package concorrencia;
public class ProdutorConsumidor {
	public static void main(String args[]) {
		Memoria umaMemoriaCompartilhada = new Memoria();
		
		Produtor umProdutor =  new Produtor(umaMemoriaCompartilhada);
		Consumidor umConsumidor = new Consumidor(umaMemoriaCompartilhada);
		
		umProdutor.start();
		umConsumidor.start();
	}
}