package concorrencia;
public class Memoria {
	private int conteudo = -1;
	private boolean acessivel = true;
	
	public synchronized void escreveNaMemoria(int valor) {
		while(!acessivel) {
			try {
				wait( );
			}
			catch ( InterruptedException e) {
				e.printStackTrace( );
			}
		}
		System.err.println( Thread.currentThread().getName() + " produzido o valor: " + valor );
		this.conteudo = valor;
		acessivel = false;
		notify( );
	}

	public synchronized int lerDaMemoria() {
		while (acessivel) {
			try {
				wait( );	
			}
			catch ( InterruptedException e) {
				e.printStackTrace( ); 
			}
		}
		System.err.println( Thread.currentThread().getName() + " consumido o valor: " + this.conteudo );
		acessivel = true;
		notify();  
		return this.conteudo;
	}
}