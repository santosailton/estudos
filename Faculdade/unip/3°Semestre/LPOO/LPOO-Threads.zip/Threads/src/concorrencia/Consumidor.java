package concorrencia;
public class Consumidor extends Thread {
	private Memoria memo;
	private int valor,soma;
	
	public Consumidor(Memoria dado) {
		super("Consumidor");
		memo = dado;
		valor = 0;
		soma = 0;
	}
	public void run() {
		do {
			try {
				Thread.sleep( ( int ) ( Math.random() * 3000 ) );
			}
			catch( InterruptedException exception ) {
				System.err.println( exception.toString() );
			}
			valor = memo.lerDaMemoria();
			soma += valor;
		} while (valor != 10);
		System.err.println(getName() + " terminou de consumir");
		System.err.println("Resultado da soma: " + soma);
	}
}