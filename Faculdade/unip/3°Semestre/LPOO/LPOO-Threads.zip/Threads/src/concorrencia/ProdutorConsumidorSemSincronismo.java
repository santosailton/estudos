package concorrencia;
/* Classe ProdutorConsumidor.java
 * Mostra duas threads modificando um objeto compartilhado.
 */

public class ProdutorConsumidorSemSincronismo {
	public static void main(String args[]) {
		ObjetoBuffer umBufferCompartilhado = new ObjetoBuffer();
		
		Produtor1 umProdutor =  new Produtor1(umBufferCompartilhado);
		Consumidor2 umConsumidor = new Consumidor2(umBufferCompartilhado);
		
		umProdutor.start();
		umConsumidor.start();
	}
}

class Produtor1 extends Thread {
	private ObjetoBuffer o_Buffer;
	
	public Produtor1(ObjetoBuffer dado) {
		super("Produtor");
		o_Buffer = dado;
	}

	public void run() {
	   for (int i=1; i<=10; i++ ) {
		   try {
			   Thread.sleep( ( int ) ( Math.random() * 3000 ) );
		   }
		   catch( InterruptedException exception ) {
	            System.err.println( exception.toString() );
	       }
		   o_Buffer.escreveBuffer( i );
	   }
	   System.err.println(getName() + " terminou de produzir");
   }
}

class Consumidor2 extends Thread {
	private ObjetoBuffer um_Buffer;

	public Consumidor2(ObjetoBuffer dado) {
	      super("Consumidor");
	      um_Buffer = dado;
	}

	public void run() {
		int valor, soma = 0;

	    do {
	    	try {
	    		Thread.sleep( (int) ( Math.random() * 3000 ) );
	        }
	    	catch( InterruptedException exception ) {
	    		System.err.println( exception.toString() );
	        }
	        valor = um_Buffer.lerBuffer();
	        soma += valor;
	    } while ( valor != 10 );
	    System.err.println( getName() + " terminou de consumir. Totalizou: " + soma);
	}
} 

class ObjetoBuffer {
	private int memoria = -1;

	public void escreveBuffer(int valor) {
		System.err.println( Thread.currentThread().getName() + " prodizindo o valor: " + valor );
		this.memoria = valor;
	}
	
	public int lerBuffer() {
		System.err.println( Thread.currentThread().getName() + " consumindo o valor: " + this.memoria );
		return this.memoria;
	}
} 