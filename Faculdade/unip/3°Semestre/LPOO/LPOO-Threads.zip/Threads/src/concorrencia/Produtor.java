package concorrencia;
public class Produtor extends Thread {
	private Memoria memo;
	
	public Produtor(Memoria dado) {
		super("Produtor");
		memo = dado;
	}
	public void run() {
		for (int i=1; i<=10; i++ ) {
			try {
				Thread.sleep( ( int ) ( Math.random() * 3000 ) );
			}
			catch( InterruptedException exception ) {
				System.err.println( exception.toString() );
			}
			memo.escreveNaMemoria(i);
		}
		System.err.println(getName() + " terminou de produzir");
	}
}