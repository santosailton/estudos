public class Thread01 {
	public static void main(String args[]) {
      System.out.println("Main: Inicio da Thread main()\n");

      ThreadBasica01 thread1, thread2, thread3, thread4;
      thread1 = new ThreadBasica01( "thread1" );
      thread2 = new ThreadBasica01( "thread2" );
      thread3 = new ThreadBasica01( "thread3" );
      thread4 = new ThreadBasica01( "thread4" );

      System.out.println( "\nMain: Disparando as threads" );

      thread1.getReferenciaThread(thread2);
      thread1.start();
      thread2.start();
      thread3.start();
      thread4.start();    

      System.out.println( "Main: Threads Basicas iniciadas\n" );

      try{
        thread1.join();
        thread2.join();
        thread3.join();
        thread4.join();
      }
      catch(InterruptedException x) {}

      System.out.println("Main: Fim da Thread main()\n");
   }
}

class ThreadBasica01 extends Thread {
   private int tempo_de_sono;
   private ThreadBasica01 namorada = null;    

   public ThreadBasica01(String nome) {
      super(nome);

      tempo_de_sono = (int) (Math.random() * 5000); 
      System.out.println("Nome: " + getName() + ";  tempo do sono: " + tempo_de_sono );
   }
   
   void getReferenciaThread(Thread t1) {
	   namorada = (ThreadBasica01) t1;
   } 
    
   public void run() {
      try {
         System.out.println( getName() + " vai comecar a dormir" );
         sleep(tempo_de_sono);
      }
      catch (InterruptedException ex) {
         System.out.println(ex.toString());
      }
       
      if (namorada != null) {
    	  try {
            namorada.join();
          }
    	  catch(InterruptedException x) {}
      }  

      System.out.println( getName() + " acordou e agora vai morrer" );
   }
}












