/**
 * Esta classe mostra como funcionam os comandos 
 * printStackTrace, getStackTrace e getMessage
 * 
 * @author Leandro C. Fernandes
 * @since 05/MAI/2009
 */

public class ExemploStackTraceElement {

	public static void metodo1() throws Exception {
		metodo2();
	}
	
	public static void metodo2() throws Exception {
		metodo3();
	}
	
	public static void metodo3() throws Exception {
		throw new Exception( "Exce��o lan�ada no m�todo #3" );
	}
	
	public static void main( String[] args ) {
		try {
			metodo1();
		}
		catch (Exception excep) {
			System.out.println( "\nMensagem da exce��o: " + excep.getMessage() );
			excep.printStackTrace();
			
			System.out.println( "Rastreamento usando 'getStackTrace'" );
			System.out.println( "\tClasse\t\t\t\tArquivo\t\t\t\tLinha\tM�todo" );
			
			StackTraceElement[] percursoDaExcecao;
			percursoDaExcecao = excep.getStackTrace();
			
			for(StackTraceElement elem : percursoDaExcecao) {
				System.out.printf( "\t%s\t", elem.getClassName() );
				System.out.printf( "%s\t", elem.getFileName() );
				System.out.printf( "%s\t", elem.getLineNumber() );
				System.out.printf( "%s\n", elem.getMethodName() );
			}
		}
	}

}