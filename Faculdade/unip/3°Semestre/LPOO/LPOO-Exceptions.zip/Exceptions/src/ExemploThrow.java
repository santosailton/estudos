/**
 * Esta classe mostra como funciona o comando throw e a diretiva throws
 * @author Leandro C. Fernandes
 * @since 05/MAI/2009
 */

public class ExemploThrow {

	public static int divide(int a, int b) throws ArithmeticException {
		System.out.println("Executando do m�todo 'divide'");
		try {
			System.out.println("\tBloco 'try' (divide)");
		    return a/b;
		}
		catch (Exception e) {
			System.out.println("\tBloco 'catch' (divide)");
			System.out.println("\t\tTratamento parcial da exce��o.");
			System.out.println("\t\tLan�a uma nova exce��o, com msg em portugu�s.");
			throw new ArithmeticException("Divis�o por zero");
			//Qualquer comando a partir daqui nunca seria executado por causa do 'throw'
		}
	}

	public static void main(String[] args) {
		int x, y, result;
		System.out.println("Executando do m�todo 'main'");
		
		x = 2; y = 0; result = 0;
		try{
			System.out.println("\tBloco 'try' (main)");
			result = divide(x,y);
			System.out.println("Resultado: " + result);
		}
		catch (Exception e) {
			System.out.println("\tBloco 'catch' (main)");
			System.out.println("\tTratamento da exce��o.");
			System.out.println("Erro: " + e.getMessage());
		}
	}

}