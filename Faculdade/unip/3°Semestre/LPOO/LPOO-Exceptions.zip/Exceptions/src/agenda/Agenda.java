package agenda;

public class Agenda {
	private Contato[] array;
	private int qtdeContatos;
	
	public Agenda() {
		array = new Contato[10];
		qtdeContatos = 0;
	}
	public Agenda(int tamanhoDaAgenda) {
		assert (tamanhoDaAgenda > 0) : "A agenda n�o pode ter " + tamanhoDaAgenda + " contatos";
		array = new Contato[tamanhoDaAgenda];
		qtdeContatos = 0;
	}
	
	public void inserir(Contato novo) throws AgendaException {
		if (qtdeContatos < getCapacidadeDaAgenda()) {
			array[qtdeContatos] = novo;
			qtdeContatos++;
		}
		else 
			throw new AgendaException("Agenda cheia");
	}
	
	public Contato procurarPor(String nomeDoContato) {
		boolean achou = false;
		int i = 0;		
		while ( (i < array.length) && (array[i] != null) && (!achou) ) {
			if ( nomeDoContato.equalsIgnoreCase( array[i].getNome() ) ) 
				achou = true;
			else
				i++;
		}		
		return (achou)? array[i]:null;
	}
	
	public int getQtdeContatosArmazenados() {
		return qtdeContatos;	
	}
	public int getCapacidadeDaAgenda() {
		return array.length;	
	}
	
	public void setContatoAt(Contato contato, int index) {
		assert ((index < 0) && (index >= getCapacidadeDaAgenda())) : "Posi��o da agenda inv�lida";
		array[index] = contato;
	}
	public Contato getContatoAt(int index) {
		assert ((index < 0) && (index >= getCapacidadeDaAgenda())) : "Posi��o da agenda inv�lida";
		return array[index];
	}
	
	public int getContatoIndex(String nomeDoContato) {
		boolean achou = false;
		int i = 0;		
		while ( (i < array.length) && (array[i] != null) && (!achou) ) {
			if ( nomeDoContato.equalsIgnoreCase( array[i].getNome() ) ) 
				achou = true;
			else
				i++;
		}		
		return (achou)?i:-1;
	}
	
	public Contato[] getTodosOsContatos() {
		if (qtdeContatos == 0)
			return null;
		else {
			Contato[] todosOsContatos;
			todosOsContatos = new Contato[qtdeContatos];
			for (int i = 0; i < qtdeContatos; i++)
				todosOsContatos[i] = array[i]; 
			return todosOsContatos;
		}
	}
}
