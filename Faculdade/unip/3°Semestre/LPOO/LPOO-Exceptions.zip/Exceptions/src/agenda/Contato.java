package agenda;

public class Contato {
	
	// Atributos
	private String nome;
	private String email;
	
	// Construtores
	public Contato() {
		this.nome = "N�o definido";
		this.email = "N�o informado";
	}
	/**
	 * @param nome Nome do contato
	 * @param email Endere�o eletr�nico do contato
	 */
	public Contato(String nome, String email) {
		this.nome = nome;
		this.email = email;
	}
	
	//M�todos de acesso e modificadores
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
}