package agenda;

import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) {

		JOptionPane.showMessageDialog(null,
				"Este aplicativo serve de exemplo para demonstrar as quest�es\n" +
				"relacionadas ao lan�amento e tratamento de exce��es, tomando\n" +
				"como exemplo uma agenda de contatos pessoais.",
				"Agenda de Contatos", JOptionPane.PLAIN_MESSAGE);
		
		// Agenda
		Agenda meusContatos;
		meusContatos = new Agenda(2);
		
		// Vari�veis de controle
		String op, nome, email;
		int opcao = 1;
		boolean desejaSair = false;
			
		do {	
			// Apresenta��o do menu
			op = JOptionPane.showInputDialog(null, 
					"(1) Inserir um contato\n" +
					"(2) Procurar por um contato\n" +
					"(3) Alterar dados de um contato\n" +
					"(4) Listar todos os contatos\n" +
					"(5) Encerrar programa\n",
					"Agenda - Menu de op��es", JOptionPane.PLAIN_MESSAGE);
			try {
				opcao = Integer.parseInt(op);
				switch (opcao) {
					case 1: // Inser��o de um novo contato na agenda
						    try {
								nome = JOptionPane.showInputDialog(null, 
										"Informe o nome:",
										"Agenda - Novo contato", JOptionPane.PLAIN_MESSAGE);
								email = JOptionPane.showInputDialog(null, 
										"Informe o e-mail:",
										"Agenda - Novo contato", JOptionPane.PLAIN_MESSAGE);
						    	meusContatos.inserir(new Contato(nome, email));
							}
							catch (AgendaException ae) {
								JOptionPane.showMessageDialog(null,
										ae.getMessage(),
										"Agenda", JOptionPane.ERROR_MESSAGE);
							}
						break;
					case 2: // Procurar por um contato
							nome = JOptionPane.showInputDialog(null, 
									"Informe o nome:",
									"Agenda - Localizar contato", JOptionPane.PLAIN_MESSAGE);
							Contato contatoProcurado = meusContatos.procurarPor(nome);
							if (contatoProcurado != null)
								JOptionPane.showMessageDialog(null,
										"Nome...: " + contatoProcurado.getNome() + "\n" +
										"E-mail.: " + contatoProcurado.getEmail() ,
										"Agenda - Contato localizado", JOptionPane.INFORMATION_MESSAGE);
							else
								JOptionPane.showMessageDialog(null,
										"Contato n�o encontrado",
										"Agenda - Localizar contato", JOptionPane.WARNING_MESSAGE);
						break;
					case 3: // Alterar as informa��es de um contato
							nome = JOptionPane.showInputDialog(null, 
									"Informe o nome:",
									"Agenda - Localizar contato", JOptionPane.PLAIN_MESSAGE);
							
							Contato contatoASerAlterado = meusContatos.procurarPor(nome);
							if (contatoASerAlterado != null) {
								nome = JOptionPane.showInputDialog(null, 
										"Nome...: " + contatoASerAlterado.getNome() + "\n" +
										"Informe o novo valor para o nome: ",
										"Agenda - Alterar informa��es do contato", JOptionPane.PLAIN_MESSAGE);
								email = JOptionPane.showInputDialog(null, 
										"E-mail.: " + contatoASerAlterado.getEmail() + "\n" +
										"Informe o novo valor para o e-mail: ",
										"Agenda - Alterar informa��es do contato", JOptionPane.PLAIN_MESSAGE);
								contatoASerAlterado.setNome(nome);
								contatoASerAlterado.setEmail(email);
							}
							else
								JOptionPane.showMessageDialog(null,
										"Contato n�o encontrado",
										"Agenda - Localizar contato", JOptionPane.WARNING_MESSAGE);
						break;
					case 4: // Listar todos os contato da agenda
						    String listagemDeContatos = "";
							Contato[] todosOsContatos = meusContatos.getTodosOsContatos();
							if (todosOsContatos != null)
								for (Contato elem : todosOsContatos) 
										listagemDeContatos += elem.getNome() + " (" + elem.getEmail() + ")\n";							
							else
								listagemDeContatos = "N�o h� contatos cadastrados nesta agenda";
							JOptionPane.showMessageDialog(null,
									listagemDeContatos,
									"Agenda - Todos os contatos", JOptionPane.PLAIN_MESSAGE);
						break;
					case 5: // Confirmar o encerrar o aplicativo
						    desejaSair = ( JOptionPane.showConfirmDialog(null,
						    						"Deseja realmente encerrar o programa?",
						    						"Agenda", JOptionPane.OK_CANCEL_OPTION )
						    				== JOptionPane.OK_OPTION )? true : false;
						break;
					default: // Tratamento das op��es inv�lidas (menu)
						     JOptionPane.showMessageDialog(null,
						    		 "Op��o inv�lida. Informe um valor entre 1 e 5.",
						    		 "Agenda", JOptionPane.ERROR_MESSAGE);
				}
			}
			catch (NumberFormatException e) {
				JOptionPane.showMessageDialog(null,
						"Valor inv�lido, informe um valor num�rico entre 1 e 5.",
						"Agenda", JOptionPane.ERROR_MESSAGE);
			}
		} while ((opcao != 5) || (!desejaSair));

		System.exit(0);
	}

}