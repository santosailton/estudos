package agenda;

@SuppressWarnings("serial")
public class AgendaException extends Exception {

	public AgendaException() {
		super("Falha na opera��o da agenda.");
	}
	public AgendaException(String msg) {
		super(msg);
	}
	public AgendaException(Throwable arg0) {
		super(arg0);
	}
	public AgendaException(String msg, Throwable arg1) {
		super(msg, arg1);
	}

}
