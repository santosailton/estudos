import java.util.Scanner;

/**
 * Esta classe mostra como funciona o comando try..catch
 * @author Leandro C. Fernandes
 * @since 05/MAI/2009
 */

public class ExemploTry2 {

	public static int divide(int a, int b) {
		return a/b;
	}
	public static void main(String[] args) {
		int x, y, result;
		boolean ok = false;
		Scanner teclado = new Scanner(System.in);
		
		while (!ok) {
			System.out.print("Informe um valor inteiro para X: ");
			x = teclado.nextInt();
			System.out.print("Informe um valor inteiro para Y: ");
			y = teclado.nextInt();
			try {
				result = divide(x,y);
				System.out.println("Resultado: " + result);
				ok = true;
			}
			catch (ArithmeticException ae) {
				System.out.println("Erro: " + ae.getMessage());
				System.out.println("Informe valores v�lidos");
			}
		}
		
	}

}
