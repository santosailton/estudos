/**
 * Esta classe mostra como funciona o comando try..catch
 * @author Leandro C. Fernandes
 * @since 05/MAI/2009
 */

public class ExemploTry {

	public static int divide(int a, int b) {
		return a/b;
	}
	public static void main(String[] args) {
		int x, y, result;
		x = 2; y = 0; result = 0;
		try {
			result = divide(x,y);
			System.out.println("Resultado: " + result);
		}
		catch (ArithmeticException ae) {
			System.out.println("Erro: " + ae.getMessage());
			ae.printStackTrace();
		}
	}

}
