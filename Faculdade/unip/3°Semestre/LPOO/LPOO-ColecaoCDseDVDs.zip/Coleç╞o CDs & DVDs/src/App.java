import java.util.Vector;
import javax.swing.JOptionPane;

public class App {
	
	private Vector colecaoCDs;
	private Vector colecaoDVDs;
	
	public App() {
		colecaoCDs = new Vector(10);
		colecaoDVDs = new Vector(10);
	}
	
	private void insere(CD novoCD) {
		colecaoCDs.add(novoCD);
	}
	
	private void insere(DVD novoDVD) {
		colecaoDVDs.add(novoDVD);
	}
	
	public void exibirColecoes() {
		for (int i = 0; i < colecaoCDs.size(); i++) {
			CD cd = (CD) colecaoCDs.get(0);
			JOptionPane.showMessageDialog(null, cd.getFichaCompleta(), "CD: " + cd.getAlbum(), JOptionPane.PLAIN_MESSAGE);
		}
	}

	public static void main(String[] args) {
		App colecaoCDseDVDs = new App();
		int op = 0;
		
		while (op != 4) {
			op = Integer.parseInt(
				JOptionPane.showInputDialog(null,
					"1. Inserir CD\n"+
					"2. Inserir DVD\n"+
					"3. Listar cole��es\n"+
					"4. Sair\n"+
					"Informe uma das op��es:",
					"Cat�logo de CDs & DVDs", JOptionPane.PLAIN_MESSAGE)
				);
			switch (op) {
				case 1:
					CD cd = new CD();
					cd.setArtista("Santana");
					cd.setAlbum("Supernatural");
					cd.setAno(2005);
					cd.setGenero("rock");
					colecaoCDseDVDs.insere(cd);
					break;
				case 2:
					//coletar as informa��es
					//instanciar um obj DVD
					//inserir na cole�ao, atrav�s do m�todo insere()
					break;
				case 3:
					colecaoCDseDVDs.exibirColecoes();
			}
		}
		
		System.exit(0);
	}

}









