
public class CD {
	private String artista;
	private String album;
	private int ano;
	private String genero;
	
	public CD() {
	}

	public String getArtista() {
		return artista;
	}

	public void setArtista(String artista) {
		this.artista = artista;
	}

	public String getAlbum() {
		return album;
	}

	public void setAlbum(String album) {
		this.album = album;
	}

	public int getAno() {
		return ano;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}
	
	public String getFichaCompleta() {
		return "Artista: " + getArtista() + "\n" +
			   "Album: " + getAlbum()+ "\n" +
			   "Ano: " + getAno() + " " + getGenero();
	}
	
}
