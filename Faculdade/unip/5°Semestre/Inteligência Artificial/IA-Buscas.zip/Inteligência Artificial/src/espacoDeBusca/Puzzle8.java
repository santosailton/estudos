package espacoDeBusca;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Esta classe modela, na forma de um estado para um espa�o de buscas, uma poss�vel situa��o
 * para o famoso quebra-cabe�as chamado 8-Puzzle. Nele temos um tabuleiro de tr�s linhas e
 * tr�s colunas, contendo oito pe�as numeradas e uma posi��o livre. As pe�as podem ser movi-
 * mentadas na vertical ou na horizontal, ocupando sempre a posi��o vazia.
 * 
 * Ex: +---+---+---+  +---+---+---+  +---+---+---+  +---+---+---+  +---+---+---+  +---+---+---+
 *     | 1 | 2 | 3 |  | 1 | 2 | 3 |  | 1 | 2 | 3 |  | 1 | 2 | 3 |  | 1 | 2 | 3 |  | 1 | 2 | 3 |
 *     +---+---+---+  +---+---+---+  +---+---+---+  +---+---+---+  +---+---+---+  +---+---+---+
 *     | 4 | 5 | 6 |  | 4 | 5 |   |  | 4 |   | 5 |  |   | 4 | 5 |  | 7 | 4 | 5 |  | 7 | 4 | 5 |
 *     +---+---+---+  +---+---+---+  +---+---+---+  +---+---+---+  +---+---+---+  +---+---+---+
 *     | 7 | 8 |   |  | 7 | 8 | 6 |  | 7 | 8 | 6 |  | 7 | 8 | 6 |  |   | 8 | 6 |  | 8 |   | 6 |
 *     +---+---+---+  +---+---+---+  +---+---+---+  +---+---+---+  +---+---+---+  +---+---+---+
 *     
 * @author Leandro C. Fernandes
 *
 */
public class Puzzle8 {
	
	private static int contGlobal = 0;	// contador global representando a qde de inst�ncias
	private int id = 0;					// atributo que sirva como um identificador
	private int nivel;					// n�vel em que o estado se encontra na �rvore de busca
	private char[] tabuleiro;			// vetor que descreve a posi��o das pe�as do quebra-cabe�as
	private Puzzle8 ancestral;			// referencia ao n� pai na �rvore de busca
	
	/**
	 * Cria uma inst�ncia para respresentar uma configura��o para o tabuleiro do quebra-cabe�as
	 */
	public Puzzle8() {
		this(new char[9], null, 0);
	}
	
	/**
	 * Permite instanciar um novo estado, j� definindo a configura��o para o tabuleiro 
	 * @param cfgTabuleiro vetor de caracteres que representa a disposi��o das pe�as
	 */
	public Puzzle8(char[] cfgTabuleiro) {
		this(cfgTabuleiro, null, 0);
	}
	
	/**
	 * Permite instanciar um novo estado, j� definindo a configura��o para o tabuleiro 
	 * @param cfgTabuleiro vetor de caracteres que representa a disposi��o das pe�as
	 * @param ancestral referencia ao nodo pai do estado corrente
	 * @param nivel altura do nodo em rela��o a raiz da �rvore
	 */
	public Puzzle8(char[] cfgTabuleiro, Puzzle8 ancestral, int nivel) {
		id = contGlobal++;
		tabuleiro = cfgTabuleiro;
		this.ancestral = ancestral;
		this.nivel = nivel;
	}
	
	/**
	 * Define o posicionamento das pe�as do quebra-cabe�as, determinando a configura��o
	 * que ser� assumida pelo tabuleiro. 
	 * @param cfgTabuleiro vetor representando a posi��o dos elementos no tabuleiro 
	 */
	public void setLayout(char[] cfgTabuleiro) {
		for (int i = 0; i < cfgTabuleiro.length; i++) {
			this.tabuleiro[i] = cfgTabuleiro[i];	
		}
	}
	
	/**
	 * Retorna a configura��o das pe�as no tabuleiro do quebra-cabe�as 
	 * @return vetor representando a configura��o do tabuleiro
	 */
	public char[] getLayout() {
		char[] cfgTabuleiro = new char[9];
		for (int i = 0; i < tabuleiro.length; i++) {
			cfgTabuleiro[i] = tabuleiro[i];
		}
		return cfgTabuleiro;
	}
	
	/**
	 * M�todo que recupera a ref�ncia do nodo pai deste estado
	 * @return refer�ncia ao nodo pai
	 */
	public Puzzle8 getAncestral() {
		return ancestral;
	}
	
	/**
	 * M�todo de acesso que permite recuperar qual o n�vel que o nodo ocupa na �rvore de busca
	 * @return
	 */
	public int getNivel() {
		return nivel;
	}
	
	/**
	 * Fun��o que gera os estados sucessores de acordo com os diferentes movimentos poss�veis
	 * a partir da configura��o do tabuleiro.
	 * @return lista de estados sucessores
	 */
	public List<Puzzle8> getSucessores() {
		List<Puzzle8> estadosSucessores = new ArrayList<Puzzle8>();
		char[] cfgNova;
		
		int posLivre = 0;
		while (tabuleiro[posLivre] != ' ')
			posLivre++;
		
		switch (posLivre) {
		case 0:
			cfgNova = getLayout();
			cfgNova[0] = cfgNova[1];
			cfgNova[1] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			cfgNova = getLayout();
			cfgNova[0] = cfgNova[3];
			cfgNova[3] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			break;
		case 1:
			cfgNova = getLayout();
			cfgNova[1] = cfgNova[0];
			cfgNova[0] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			cfgNova = getLayout();
			cfgNova[1] = cfgNova[2];
			cfgNova[2] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			cfgNova = getLayout();
			cfgNova[1] = cfgNova[4];
			cfgNova[4] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			break;
		case 2:
			cfgNova = getLayout();
			cfgNova[2] = cfgNova[1];
			cfgNova[1] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			cfgNova = getLayout();
			cfgNova[2] = cfgNova[5];
			cfgNova[5] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			break;
		case 3:
			cfgNova = getLayout();
			cfgNova[3] = cfgNova[0];
			cfgNova[0] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			cfgNova = getLayout();
			cfgNova[3] = cfgNova[4];
			cfgNova[4] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			cfgNova = getLayout();
			cfgNova[3] = cfgNova[6];
			cfgNova[6] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			break;
		case 4:
			cfgNova = getLayout();
			cfgNova[4] = cfgNova[1];
			cfgNova[1] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			cfgNova = getLayout();
			cfgNova[4] = cfgNova[5];
			cfgNova[5] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			cfgNova = getLayout();
			cfgNova[4] = cfgNova[7];
			cfgNova[7] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			cfgNova = getLayout();
			cfgNova[4] = cfgNova[3];
			cfgNova[3] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			break;
		case 5:
			cfgNova = getLayout();
			cfgNova[5] = cfgNova[2];
			cfgNova[2] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			cfgNova = getLayout();
			cfgNova[5] = cfgNova[8];
			cfgNova[8] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			cfgNova = getLayout();
			cfgNova[5] = cfgNova[4];
			cfgNova[4] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			break;
		case 6:
			cfgNova = getLayout();
			cfgNova[6] = cfgNova[3];
			cfgNova[3] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			cfgNova = getLayout();
			cfgNova[6] = cfgNova[7];
			cfgNova[7] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			break;
		case 7:
			cfgNova = getLayout();
			cfgNova[7] = cfgNova[4];
			cfgNova[4] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			cfgNova = getLayout();
			cfgNova[7] = cfgNova[8];
			cfgNova[8] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			cfgNova = getLayout();
			cfgNova[7] = cfgNova[6];
			cfgNova[6] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			break;
		case 8:
			cfgNova = getLayout();
			cfgNova[8] = cfgNova[5];
			cfgNova[5] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			cfgNova = getLayout();
			cfgNova[8] = cfgNova[7];
			cfgNova[7] = ' ';
			estadosSucessores.add(new Puzzle8(cfgNova,this, this.nivel+1));
			break;
		}
		
		return estadosSucessores;
	}

	/**
	 * Retorna uma String correspondente a posi��o das pe�as no tabuleiro do quebra-cabe�as 
	 */
	public String toString() {
		String msg = "";
		msg += "+---+---+---+";
		msg += "\n| " + tabuleiro[0] + " | " + tabuleiro[1] + " | " + tabuleiro[2] + " |\n";
		msg += "+---+---+---+";
		msg += "\n| " + tabuleiro[3] + " | " + tabuleiro[4] + " | " + tabuleiro[5] + " |  Nodo #" + id + "  N�vel: " + nivel + "\n";
		msg += "+---+---+---+";
		msg += "\n| " + tabuleiro[6] + " | " + tabuleiro[7] + " | " + tabuleiro[8] + " |\n";
		msg += "+---+---+---+";
		return msg;
	}

	/**
	 * Implementa a compara��o entre dois estados, sendo baseada na disposi��o das pe�as no
	 * tabuleiro do quebra-cabe�as
	 */
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Puzzle8 other = (Puzzle8) obj;
		if (!Arrays.equals(tabuleiro, other.tabuleiro))
			return false;
		return true;
	}	
	
}
