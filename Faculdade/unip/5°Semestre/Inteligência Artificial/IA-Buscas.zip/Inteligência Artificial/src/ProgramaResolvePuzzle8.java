import espacoDeBusca.Puzzle8;
import estrategiasDeBusca.*;

/**
 * Este programa emprega t�cnicas de intelig�ncia artificial para descobrir os movimentos
 * necess�rios para solucionar o problema do "Quebra-cabe�as de 8" ou Puzzle-8.
 * 
 * @author Leandro C. Fernandes
 *
 */
public class ProgramaResolvePuzzle8 {

	public static void main(String[] args) {
		
		/* As linhas de c�digo a seguir descrevem uma configura��o poss�vel para o tabuleiro
		 * do quebra-cabe�as, obtida a partir do embaralhamento de suas pe�as (dada como in�cio).
		 * Como objetivo, inteciona-se obter que as pe�as estjam dispostas numa sequencia ordenada
		 * (que aqui � representada como objetivo).
		 * 
		 *		Embaralhada:	  Organizada:
		 *		+---+---+---+	 +---+---+---+
		 * 		| 1 | 2 |   |	 | 1 | 2 | 3 |
		 * 		+---+---+---+	 +---+---+---+
		 *		| 4 | 6 | 3 |	 | 4 | 5 | 6 |
		 * 		+---+---+---+	 +---+---+---+
		 * 		| 7 | 5 | 8 |	 | 7 | 8 |   |
		 * 		+---+---+---+	 +---+---+---+
		 */
		
		char[] cfgEmbarralhada = new char[9];
		cfgEmbarralhada[0] = '1'; cfgEmbarralhada[1] = '2'; cfgEmbarralhada[2] = ' ';
		cfgEmbarralhada[3] = '4'; cfgEmbarralhada[4] = '6'; cfgEmbarralhada[5] = '3';
		cfgEmbarralhada[6] = '7'; cfgEmbarralhada[7] = '5'; cfgEmbarralhada[8] = '8';
		
		char[] cfgOrganizada = new char[9];
		cfgOrganizada[0] = '1'; cfgOrganizada[1] = '2'; cfgOrganizada[2] = '3';
		cfgOrganizada[3] = '4'; cfgOrganizada[4] = '5'; cfgOrganizada[5] = '6';
		cfgOrganizada[6] = '7'; cfgOrganizada[7] = '8'; cfgOrganizada[8] = ' ';
		
		
		/* A partir das configura��es especificadas acima vamos criar os estados necess�rios para
		 * aplicar uma estrat�gia de busca, definindo o estado inicial e o estado objetivo (meta).
		 */		
		Puzzle8 estObjetivo = new Puzzle8(cfgOrganizada);
		Puzzle8 estInicial = new Puzzle8(cfgEmbarralhada);
		
		/* Como sugest�o, recomendamos que experimente executar esse programa v�rias vezes, cada
		 * qual testando uma das diferentes estrat�gias implementadas. Em todos os casos � poss�vel
		 * habilitar um mecanismo de depura��o atrav�s do comando "objBusca.setDebug(true)" imedia-
		 * tamente antes do comando "objBusca.buscarSolucao()". Isso permitir� que voc� observe qual
		 * estado est� sendo visitado e quais estados est�o sendo gerados como sucessores.
		 */

		System.out.println("--:: ----- Busca em Largura ------- ::--");
		BuscaEmLargura buscaLarg = new BuscaEmLargura();
		buscaLarg.setInicio(estInicial);
		buscaLarg.setMeta(estObjetivo);
		buscaLarg.buscarSolucao();
		buscaLarg.printSolucao();
		System.out.println("--:: ------------------------------ ::--");
		
//		System.out.println("--:: --- Busca em Profundidade ---- ::--");
//		BuscaEmProfundidade buscaProf = new BuscaEmProfundidade();
//		buscaProf.setInicio(estInicial);
//		buscaProf.setMeta(estObjetivo);
//		buscaProf.setDebug(true);
//		buscaProf.buscarSolucao();
//		buscaProf.printSolucao();
//		System.out.println("--:: ------------------------------ ::--");
		
//		System.out.println("--:: Busca em Profundidade Limitada ::--");
//		BuscaEmProfundidadeLimitada buscaProfLim = new BuscaEmProfundidadeLimitada();
//		buscaProfLim.setInicio(estInicial);
//		buscaProfLim.setMeta(estObjetivo);
//		buscaProfLim.setLimite(30);
//		buscaProfLim.buscarSolucao();
//		buscaProfLim.printSolucao();
//		System.out.println("--:: ------------------------------ ::--");
		
		System.exit(0);
	}

}
