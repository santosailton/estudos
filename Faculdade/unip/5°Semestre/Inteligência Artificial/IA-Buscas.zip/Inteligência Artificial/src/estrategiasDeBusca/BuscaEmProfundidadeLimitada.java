package estrategiasDeBusca;

import java.util.Stack;

import espacoDeBusca.Puzzle8;

/**
 * Esta classe implementa a estrat�gia de busca cega conhecida como "Busca em Profundidade Limitada",
 * em que o espa�o de estados � � explorada usando a estrat�gia de busca profundidade por�m conside-
 * rando um limite m�ximo para a expans�o dos ramos.
 * 
 * @author Leandro C. Fernandes
 *
 */
public class BuscaEmProfundidadeLimitada extends BuscaCega {
	
	private Stack<Puzzle8> caminho;		// armazena os nodos que comp�e o caminho da solu��o
	private Stack<Puzzle8> borda;		// pilha de armazenamento dos nodos abertos (n�o-expandidos)
	private int limite;					// define o limite (em termos de n�vel) da busca em profundidade 
	
	/**
	 * Construtor padr�o
	 */
	public BuscaEmProfundidadeLimitada() {
		super();
		borda = new Stack<Puzzle8>();
		caminho = new Stack<Puzzle8>();
	}
	/**
	 * Construtor parametrizado que permite definir os par�metros de busca
	 * @param estadoInicial uma configura��o poss�vel do quebra-cabe�as usada como estado inicial de busca
	 * @param estadoObjetivo uma configura��o poss�vel do quebra-cabe�as usado como meta para a busca
	 */
	public BuscaEmProfundidadeLimitada(Puzzle8 estadoInicial, Puzzle8 estadoObjetivo, int limite) {
		super(estadoInicial,estadoObjetivo);
		borda = new Stack<Puzzle8>();
		caminho = new Stack<Puzzle8>();
		this.limite = limite;
	}
	
	public void setLimite(int limite) {
		this.limite = limite;
	}
	
	public int getLimite() {
		return limite;
	}
	
	/**
	 * Reescrita do m�todo de busca que implementa a estrat�gia de busca em profundidade limitada
	 */
	@Override
	public void buscarSolucao() {
		Puzzle8 estadoCorrente = getInicio();
		while ( (estadoCorrente != null) && (!estadoCorrente.equals(getMeta())) ) {
			if (isDebuging()) System.out.println("Visitando o estado:\n" + estadoCorrente);
			if (estadoCorrente.getNivel() <= limite) {
				if (isDebuging()) System.out.println("Que gerou os seguintes sucessores:");
				for (Puzzle8 estado : estadoCorrente.getSucessores()) {
					if (isDebuging()) System.out.println(estado);
					borda.push(estado);
				}
			}
			estadoCorrente = borda.pop();
			if (isDebuging()) try { Thread.sleep(500); } catch (InterruptedException e) {}
		}
		// Comp�e o caminho percorrendo o sentido inverso at� que seja encontrada a raiz
		caminho.add(estadoCorrente);
		while (estadoCorrente.getAncestral() != null) {
			estadoCorrente = estadoCorrente.getAncestral();
			caminho.add(estadoCorrente);
		}
	}
	
	@Override
	public void printSolucao() {
		while (!caminho.isEmpty()) {
			System.out.println(caminho.pop());
		}
	}
}
