package estrategiasDeBusca;

import espacoDeBusca.Puzzle8;

/**
 * Esta classe implementa a estrutura b�sica para uma estrat�gia de busca cega, na qual explorar�
 * o espa�o de estados na forma de uma �rvore de busca, expandindo seus nodos de segundo o algoritmo
 * que implementa.
 * 
 * @author Leandro C. Fernandes
 *
 */
public abstract class BuscaCega {
	
	private boolean debugOn;			// flag de modo depura��o
	private Puzzle8 inicio;				// representa o estado inicial da busca
	private Puzzle8 meta; 				// representa o estado meta (objetivo)
	
	/**
	 * Construtor padr�o
	 */
	public BuscaCega() {
		debugOn = false;
		inicio = null;
		meta = null;
	}
	
	/**
	 * Construtor parametrizado que permite definir os par�metros de busca
	 * @param estadoInicial uma configura��o poss�vel do quebra-cabe�as usada como estado inicial de busca
	 * @param estadoObjetivo uma configura��o poss�vel do quebra-cabe�as usado como meta para a busca
	 */
	public BuscaCega(Puzzle8 estadoInicial, Puzzle8 estadoObjetivo) {
		this();
		setInicio(estadoInicial);
		setMeta(estadoObjetivo);
	}
	
	/**
	 * Habilita ou desabilita o modo de depura��o, exibindo os nodes visitados e abertos
	 * pelo algoritmo durante a busca
	 * @param status true ou false (default)
	 */
	public void setDebug(boolean status) {
		debugOn = status;
	}
	
	/**
	 * Restorna se o modo de depura��o est� ativo
	 * @return status do modo de depura��o
	 */
	public boolean isDebuging() {
		return debugOn;
	}
	
	/**
	 * Define o estado inicial para a busca ao qual o processo de expans�o (fun��o que
	 * gera os estados sucessores) utiliza como ponto de partida. 
	 * @param estadoInicial uma configura��o poss�vel para o tabuleiro do quebra-cabe�as
	 */
	public void setInicio(Puzzle8 estadoInicial) {
		this.inicio = estadoInicial;
	}
	
	/**
	 * M�todo de acesso que recupera o estado inicial a ser utilizado pela busca
	 * @return uma configura��o poss�vel para o tabuleiro do quebra-cabe�as
	 */
	public Puzzle8 getInicio() {
		return this.inicio;
	}
	
	/**
	 * Define o estado meta para o processo de busca, o qual ser� considerado como o
	 * objetivo da procura pelo espa�o de estados. 
	 * @param estadoObjetivo uma configura��o poss�vel para o tabuleiro do quebra-cabe�as
	 */
	public void setMeta(Puzzle8 estadoObjetivo) {
		this.meta = estadoObjetivo;
	}
	
	/**
	 * Recupera a configura��o do tabuleiro que descreve o objetivo da busca 
	 * @return uma configura��o poss�vel para o tabuleiro do quebra-cabe�as
	 */
	public Puzzle8 getMeta() {
		return meta;
	}
	
	/**
	 * M�todo que implementar� a estrat�gia de busca
	 */
	public abstract void buscarSolucao();
	
	/**
	 * Este m�todo imprime na console os movimentos correspondentes a solu��o do problema
	 */
	public abstract void printSolucao();
	
}
