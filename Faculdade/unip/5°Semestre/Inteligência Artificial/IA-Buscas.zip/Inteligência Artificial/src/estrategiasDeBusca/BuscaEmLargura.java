package estrategiasDeBusca;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

import espacoDeBusca.Puzzle8;

/**
 * Esta classe implementa a estrat�gia de busca cega conhecida como "Busca em Largura", na
 * qual o espa�o de estados � pesquisado na forma de uma �rvore de busca explorada n�vel a
 * n�vel, sempre visitando os nodos n�o-expandindos mais pr�ximos da raiz primeiro.
 * 
 * @author Leandro C. Fernandes
 *
 */
public class BuscaEmLargura extends BuscaCega {
	
	private Queue<Puzzle8> borda;		// fila de armazenamento dos nodos abertos (n�o-expandidos)
	private Stack<Puzzle8> caminho;		// armazena os nodos que comp�e o caminho da solu��o
	
	/**
	 * Construtor padr�o
	 */
	public BuscaEmLargura() {
		super();
		borda = new LinkedList<Puzzle8>();
		caminho = new Stack<Puzzle8>();
	}
	/**
	 * Construtor parametrizado que permite definir os par�metros de busca
	 * @param estadoInicial uma configura��o poss�vel do quebra-cabe�as usada como estado inicial de busca
	 * @param estadoObjetivo uma configura��o poss�vel do quebra-cabe�as usado como meta para a busca
	 */
	public BuscaEmLargura(Puzzle8 estadoInicial, Puzzle8 estadoObjetivo) {
		super(estadoInicial,estadoObjetivo);
		borda = new LinkedList<Puzzle8>();
		caminho = new Stack<Puzzle8>();
	}
	
	/**
	 * Reescrita do m�todo de busca que implementa a estrat�gia de busca em largura
	 */
	@Override
	public void buscarSolucao() {
		Puzzle8 estadoCorrente = getInicio();
		// Procurar pela solu��o enquanto houver um estado e este ainda n�o for o objetivo
		while ( (estadoCorrente != null) && (!estadoCorrente.equals(getMeta()))) {
			if (isDebuging()) System.out.println("Visitando o estado:\n" + estadoCorrente);
			if (isDebuging()) System.out.println("Que gerou os seguintes sucessores:");
			for (Puzzle8 estado : estadoCorrente.getSucessores()) {
				if (isDebuging()) System.out.println(estado);
				borda.add(estado);
			}
			estadoCorrente = borda.poll();
			if (isDebuging()) try { Thread.sleep(500); } catch (InterruptedException e) {}
		}
		// Comp�e o caminho percorrendo o sentido inverso at� que seja encontrada a raiz
		caminho.add(estadoCorrente);
		while (estadoCorrente.getAncestral() != null) {
			estadoCorrente = estadoCorrente.getAncestral();
			caminho.add(estadoCorrente);
		}
	}

	@Override
	public void printSolucao() {
		while (!caminho.isEmpty()) {
			System.out.println(caminho.pop());
		}
	}	
	
}
