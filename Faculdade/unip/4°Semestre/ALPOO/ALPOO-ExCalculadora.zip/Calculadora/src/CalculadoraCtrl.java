import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

public class CalculadoraCtrl implements ActionListener {
	
	private CalculadoraUI gui;
	private double op1, op2;
	private char operacao;
	
	public CalculadoraCtrl() {
		operacao = '=';
	}
	
	private void clear() {
		op2 = 0;
		gui.clearDisplay();
	}
	
	private void clearAll() {
		op1 = op2 = 0;
		operacao = '=';
		gui.clearDisplay();
	}
	
	public void setInterface(CalculadoraUI gui) {
		this.gui = gui;
	}
	
	public void init() {
		clearAll();
		gui.setVisible(true);
	}

	public void actionPerformed(ActionEvent ae) {
		if (ae.getActionCommand().equals("soma")) {
			op2 = gui.getValor();
			calcula();
			operacao = '+';
			gui.clearOnNext();
		}
		else if (ae.getActionCommand().equals("subtra��o")) {
			op2 = gui.getValor();
			calcula();
			operacao = '-';
			gui.clearOnNext();
		}
		else if (ae.getActionCommand().equals("multiplica��o")) {
			op2 = gui.getValor();
			calcula();
			operacao = '*';
			gui.clearOnNext();
		}
		else if (ae.getActionCommand().equals("divis�o")) {
			op2 = gui.getValor();
			calcula();
			operacao = '/';
			gui.clearOnNext();
		}
		else if (ae.getActionCommand().equals("igual")) {
			op2 = gui.getValor();
			calcula();
			operacao = '=';
			gui.setDisplay(op1);
		}
		else if (ae.getActionCommand().equals("clearE")) {
			clear();
		}
		else if (ae.getActionCommand().equals("clear")) {
			clearAll();
		}
	}

	private void calcula() {
		switch(operacao) {
		case '=':
			op1 = op2;
			break;
		case '+':
			op1 = op1 + op2;
			break;
		case '-':
			op1 = op1 - op2;
			break;
		case '*':
			op1 = op1 * op2;
			break;
		case '/':
			if (op2 == 0)
				JOptionPane.showMessageDialog(gui,
						"Oopera��o inv�lida! N�o existe divis�o por zero.",
						"Calculadora", JOptionPane.ERROR_MESSAGE);
			else
				try {
					op1 = op1 / op2;
				} catch (ArithmeticException e) {
					JOptionPane.showMessageDialog(gui,
							"Erro durante o c�lculo da divis�o.\n("+e.getMessage()+")",
							"Calculadora", JOptionPane.ERROR_MESSAGE);
				}
			break;
		}
		gui.setDisplay(op1);
	}

}
