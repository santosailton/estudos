public class AppCalculadora {
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		CalculadoraUI janela = new CalculadoraUI();
		CalculadoraCtrl calc = new CalculadoraCtrl();

		calc.setInterface(janela);
		janela.setControle(calc);
		
		calc.init();
	}
}
