import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.GridBagLayout;

import javax.swing.JButton;

import java.awt.GridBagConstraints;
import java.awt.Insets;

import javax.swing.JTextField;

import java.awt.SystemColor;
import java.awt.Font;

import javax.swing.SwingConstants;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

@SuppressWarnings("serial")
public class CalculadoraUI extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTextField tfDisplay;
	private JButton btnCE, btnC, btnSom, btnSub, btnMul, btnDiv, btnIgual, btnSep,
					btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9, btn0;
	private boolean hasSeparador, clearNext;

	/**
	 * Create the frame.
	 */
	public CalculadoraUI() {
		setResizable(false);
		setTitle("Calculadora");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 224, 249);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[] {0, 0, 0, 10, 0, 0};
		gbl_contentPane.rowHeights = new int[] {40, 10, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, 1.0, 1.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		tfDisplay = new JTextField();
		tfDisplay.setBackground(SystemColor.controlLtHighlight);
		tfDisplay.setHorizontalAlignment(SwingConstants.RIGHT);
		tfDisplay.setText("1234567890");
		tfDisplay.setFont(new Font("Monospaced", Font.PLAIN, 20));
		tfDisplay.setEditable(false);
		GridBagConstraints gbc_tfDisplay = new GridBagConstraints();
		gbc_tfDisplay.gridwidth = 5;
		gbc_tfDisplay.insets = new Insets(0, 0, 5, 0);
		gbc_tfDisplay.fill = GridBagConstraints.BOTH;
		gbc_tfDisplay.gridx = 0;
		gbc_tfDisplay.gridy = 0;
		contentPane.add(tfDisplay, gbc_tfDisplay);
		tfDisplay.setColumns(10);
		
		btnCE = new JButton("CE");
		btnCE.setActionCommand("clear");
		GridBagConstraints gbc_btnCE = new GridBagConstraints();
		gbc_btnCE.anchor = GridBagConstraints.EAST;
		gbc_btnCE.gridwidth = 2;
		gbc_btnCE.insets = new Insets(0, 0, 5, 5);
		gbc_btnCE.gridx = 2;
		gbc_btnCE.gridy = 2;
		contentPane.add(btnCE, gbc_btnCE);
		
		btnC = new JButton("C");
		btnC.setActionCommand("clearE");
		GridBagConstraints gbc_btnC = new GridBagConstraints();
		gbc_btnC.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnC.insets = new Insets(0, 0, 5, 0);
		gbc_btnC.gridx = 4;
		gbc_btnC.gridy = 2;
		contentPane.add(btnC, gbc_btnC);
		
		btn0 = new JButton("0");
		btn0.addActionListener(this);
		GridBagConstraints gbc_btn0 = new GridBagConstraints();
		gbc_btn0.insets = new Insets(0, 0, 0, 5);
		gbc_btn0.gridx = 1;
		gbc_btn0.gridy = 6;
		contentPane.add(btn0, gbc_btn0);
		
		btn1 = new JButton("1");
		btn1.addActionListener(this);
		GridBagConstraints gbc_btn1 = new GridBagConstraints();
		gbc_btn1.insets = new Insets(0, 0, 5, 5);
		gbc_btn1.gridx = 0;
		gbc_btn1.gridy = 5;
		contentPane.add(btn1, gbc_btn1);
		
		btn2 = new JButton("2");
		btn2.addActionListener(this);
		GridBagConstraints gbc_btn2 = new GridBagConstraints();
		gbc_btn2.insets = new Insets(0, 0, 5, 5);
		gbc_btn2.gridx = 1;
		gbc_btn2.gridy = 5;
		contentPane.add(btn2, gbc_btn2);
		
		btn3 = new JButton("3");
		btn3.addActionListener(this);
		GridBagConstraints gbc_btn3 = new GridBagConstraints();
		gbc_btn3.insets = new Insets(0, 0, 5, 5);
		gbc_btn3.gridx = 2;
		gbc_btn3.gridy = 5;
		contentPane.add(btn3, gbc_btn3);
		
		btn4 = new JButton("4");
		btn4.setMnemonic('4');
		btn4.addActionListener(this);
		GridBagConstraints gbc_btn4 = new GridBagConstraints();
		gbc_btn4.insets = new Insets(0, 0, 5, 5);
		gbc_btn4.gridx = 0;
		gbc_btn4.gridy = 4;
		contentPane.add(btn4, gbc_btn4);
		
		btn5 = new JButton("5");
		btn5.addActionListener(this);
		GridBagConstraints gbc_btn5 = new GridBagConstraints();
		gbc_btn5.insets = new Insets(0, 0, 5, 5);
		gbc_btn5.gridx = 1;
		gbc_btn5.gridy = 4;
		contentPane.add(btn5, gbc_btn5);
		
		btn6 = new JButton("6");
		btn6.addActionListener(this);
		GridBagConstraints gbc_btn6 = new GridBagConstraints();
		gbc_btn6.insets = new Insets(0, 0, 5, 5);
		gbc_btn6.gridx = 2;
		gbc_btn6.gridy = 4;
		contentPane.add(btn6, gbc_btn6);
		
		btn7 = new JButton("7");
		btn7.addActionListener(this);
		GridBagConstraints gbc_btn7 = new GridBagConstraints();
		gbc_btn7.insets = new Insets(0, 0, 5, 5);
		gbc_btn7.gridx = 0;
		gbc_btn7.gridy = 3;
		contentPane.add(btn7, gbc_btn7);
		
		btn8 = new JButton("8");
		btn8.addActionListener(this);
		GridBagConstraints gbc_btn8 = new GridBagConstraints();
		gbc_btn8.insets = new Insets(0, 0, 5, 5);
		gbc_btn8.gridx = 1;
		gbc_btn8.gridy = 3;
		contentPane.add(btn8, gbc_btn8);
		
		btn9 = new JButton("9");
		btn9.addActionListener(this);
		GridBagConstraints gbc_btn9 = new GridBagConstraints();
		gbc_btn9.insets = new Insets(0, 0, 5, 5);
		gbc_btn9.gridx = 2;
		gbc_btn9.gridy = 3;
		contentPane.add(btn9, gbc_btn9);
				
		btnSep = new JButton(",");
		btnSep.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!hasSeparador) {
					if (clearNext) {
						tfDisplay.setText( "0.");
						clearNext = false;
					}
					else
						tfDisplay.setText( tfDisplay.getText() + ".");
					hasSeparador = true;
				}
			}
		});
		GridBagConstraints gbc_btnSep = new GridBagConstraints();
		gbc_btnSep.insets = new Insets(0, 0, 0, 5);
		gbc_btnSep.gridx = 0;
		gbc_btnSep.gridy = 6;
		contentPane.add(btnSep, gbc_btnSep);
		
		btnIgual = new JButton("=");
		btnIgual.setActionCommand("igual");
		GridBagConstraints gbc_btnIgual = new GridBagConstraints();
		gbc_btnIgual.insets = new Insets(0, 0, 0, 5);
		gbc_btnIgual.gridx = 2;
		gbc_btnIgual.gridy = 6;
		contentPane.add(btnIgual, gbc_btnIgual);
		
		btnSom = new JButton("+");
		btnSom.setActionCommand("soma");
		GridBagConstraints gbc_btnSom = new GridBagConstraints();
		gbc_btnSom.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnSom.insets = new Insets(0, 0, 5, 0);
		gbc_btnSom.gridx = 4;
		gbc_btnSom.gridy = 3;
		contentPane.add(btnSom, gbc_btnSom);
		
		btnSub = new JButton("-");
		btnSub.setActionCommand("subtra��o");
		GridBagConstraints gbc_btnSub = new GridBagConstraints();
		gbc_btnSub.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnSub.insets = new Insets(0, 0, 5, 0);
		gbc_btnSub.gridx = 4;
		gbc_btnSub.gridy = 4;
		contentPane.add(btnSub, gbc_btnSub);
		
		btnMul = new JButton("x");
		btnMul.setActionCommand("multiplica��o");
		GridBagConstraints gbc_btnMul = new GridBagConstraints();
		gbc_btnMul.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnMul.insets = new Insets(0, 0, 5, 0);
		gbc_btnMul.gridx = 4;
		gbc_btnMul.gridy = 5;
		contentPane.add(btnMul, gbc_btnMul);
		
		btnDiv = new JButton("/");
		btnDiv.setActionCommand("divis�o");
		GridBagConstraints gbc_btnDiv = new GridBagConstraints();
		gbc_btnDiv.fill = GridBagConstraints.HORIZONTAL;
		gbc_btnDiv.gridx = 4;
		gbc_btnDiv.gridy = 6;
		contentPane.add(btnDiv, gbc_btnDiv);

		hasSeparador = false;
		clearNext = false;
	}
	
	public void clearDisplay() {
		tfDisplay.setText("0");
		hasSeparador = false;
	}
	
	public void clearOnNext() {
		clearNext = true;
		hasSeparador = false;
	}
	
	public void setDisplay(double valor) {
		tfDisplay.setText("" + valor);
	}
	
	public double getValor() {
		return Double.parseDouble( tfDisplay.getText() );
	}
	
	public void setControle(ActionListener controle) {
		btnCE.addActionListener(controle);
		btnC.addActionListener(controle);
		btnSom.addActionListener(controle);
		btnSub.addActionListener(controle);
		btnMul.addActionListener(controle);
		btnDiv.addActionListener(controle);
		btnIgual.addActionListener(controle);
	}

	public void actionPerformed(ActionEvent ae) {
		if (tfDisplay.getText().equals("0") || clearNext)
			tfDisplay.setText( ((JButton)ae.getSource()).getText() );
		else
			tfDisplay.setText( tfDisplay.getText() + ((JButton)ae.getSource()).getText() );
		clearNext = false;
	}
	
}
