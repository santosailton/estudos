#include <linux/module.h>
#include <linux/init.h>

static int __init hellokernel_init(void)
{
	printk(KERN_ALERT "%s: Hello Kernel!!!!!!\n", THIS_MODULE->name);
	return(0);
}

static void __exit hellokernel_exit(void)
{
	printk(KERN_ALERT "%s: Bye Bye Kernel!!!!!!\n", THIS_MODULE->name);
}

module_init(hellokernel_init);
module_exit(hellokernel_exit);
MODULE_AUTHOR("Rene S. Pinto");
MODULE_DESCRIPTION("My first Linux kernel module");
MODULE_LICENSE("GPL");

